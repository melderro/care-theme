<?php
/**
 * This file calls the app.php file.
 *
 * All the fun stuff is in the app.php file and its imports. This is just here
 * because WordPress requires a functions.php file.
 *
 * You can add code below, but the structure of this project allows for better
 * placement of files outside of the root directory. If you're unfamiliar with
 * where something should go, poke around!
 */
require_once( dirname( __FILE__ ) . '/app/app.php' );