<?php
/**
 * WordPress footer and anything else needed here
 */
do_action('get_footer');
wp_footer();
?>
