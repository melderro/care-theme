<?php // Footer Newsletter Signup ?>
<div class="o-footerNewsletterSignup">
  <h2 class="m-footerNewsletterSignup__title">get our latest news</h2>
  <form>
  <input type="text" id="fname" name="fname">
  </form>
</div>