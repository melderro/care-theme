<?php // Main Category Introductory paragraph content ?>
<div class="o-maincategoryintroContent">
  <div class="o-maincategoryintroContent__contenttitle">
    <h2 class="o-maincategoryintroContent__title">
      <?php the_field('main_category_intro_title'); ?>
    </h2>  
  </div>
  <div class="o-maincategoryintroContent__content">
    <?php the_field('main_category_intro_text'); ?>
  </div>
</div>
