<?php // General Secondary content ?>
<div class="o-generalbodySecondaryContent">
  <div class="o-generalbodySecondaryContent__contentContainer">
    <div class="o-generalbodySecondaryContent__contenttitle">
      <h2 class="o-generalbodySecondaryContent__title">
      <?php the_field('general_bottom_content_title'); ?>
      </h2>  
    </div>
    <div class="o-generalbodySecondaryContent__content">
    <?php the_field('general_bottom_content_text'); ?>
    </div>
  </div>
</div>
