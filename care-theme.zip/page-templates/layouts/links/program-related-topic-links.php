<?php // Program Related Topics content ?>
<div class="o-programRelatedTopics">  
<h2>Related Topics Heading</h2>
  <ul class="m-programRelatedTopics__list">
    <li>
      <a><span class="m-programRelatedTopics__Category">Program Category</span><span>list item<span></a>
    </li>
    <li>
      <a><span class="m-programRelatedTopics__Category">Program Category</span><span>list item<span></a>
    </li>
    <li>
      <a><span class="m-programRelatedTopics__Category">Program Category</span><span>list item<span></a>
    </li>
    <li>
      <a><span class="m-programRelatedTopics__Category">Program Category</span><span>list item<span></a>
    </li>
  </ul>
</div>
